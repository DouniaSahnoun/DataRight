# Pack financier du jour 1

## Ce que la developpeuse peut utiliser immediatement

- `contracts/` contient quatre PDF textuels avec des clauses numerotees et des pages stables.
- `data/project_context.json` regroupe tout le cas de demonstration dans un seul fichier.
- `data/components.csv`, `products.csv`, `dependencies.csv` et `documents.csv` peuvent alimenter la base de donnees.
- `data/qa_questions.csv` contient cinq questions de reference avec reponses et citations attendues.
- `DataRights_DD_modele_financier.xlsx` est la reference lisible et chiffrée du financier.

## Histoire de demonstration

Asteria AI SAS realise 700 000 EUR d'ARR avec trois produits. Deux produits representant 540 000 EUR d'ARR utilisent Atlas Business Corpus, alors que le document D01 limite cette base a la recherche interne non productive. Le troisieme produit represente 160 000 EUR d'ARR et depend de deux composants pour lesquels aucun document de droits n'est present dans la data room.

L'application doit afficher des **revenus associes a une verification**, jamais une perte certaine. L'absence d'un document ne prouve pas qu'un droit n'existe pas.

## Parcours minimal pour la developpeuse aujourd'hui

1. Importer les quatre PDF et conserver le numero de page.
2. Repondre aux cinq questions de reference avec un passage source.
3. Retourner `insufficient_evidence` pour Q05 au lieu d'inventer une autorisation.
4. Afficher les trois produits et leurs composants a partir des CSV.
5. Montrer 540 000 EUR d'ARR associe a la restriction explicite de D01.

## Convention de priorite financiere

Pour eviter les doubles comptes, chaque produit est affecte a une seule categorie de revue :

1. restriction explicite ;
2. document de droits manquant ;
3. droit commercial documente.

Cette convention sert a la demonstration et ne constitue ni un avis juridique ni une methode de valorisation.
