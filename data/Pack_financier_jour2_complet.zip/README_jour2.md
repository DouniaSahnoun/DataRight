# Pack financier du jour 2

Le document principal est `Dossier_jour2_DataRights_DD.docx`. Il explique le scénario, les calculs, les nouveaux contrats, les vingt questions et les consignes techniques.

## Fichiers à transmettre à la développeuse

- `contracts/` : huit PDF textuels, D01 à D08.
- `data/project_context_developpeuse.json` : scénario complet sans les questions réservées.
- `data/questions_developpeuse.json` : douze questions à utiliser pendant le développement.
- `data/document_relationships.json` : relations avenant, addendum, mauvaise entité et brouillon.

Ne transmettez ni `Dossier_jour2_DataRights_DD.docx`, ni `project_context_day2.json`, ni `questions_reservees_financier.json` avant le test indépendant : ces trois fichiers contiennent les huit questions réservées.
